/*BALDO CRISTIAN
Un metodo grossolano per cifrare un testo consiste nello ‘spostare’ ogni lettera a una distanza prefissata nell’alfabeto: ogni ‘a’ diventa, ad esempio, una ‘g’, ogni ‘b’ diventa una ‘h’, e così via, ricominciando dall’inizio dell’alfabeto quando si raggiunge la ‘z’
(nell’esempio, la lettera ‘t’ verrebbe trasformata nella ‘z’ e la ‘u’ nella ‘a’).
Scrivete un programma che legge un testo e stampa il testo cifrato, fissando con una direttiva define la chiave, cioe la distanza della cifratura. Considerate l’alfabeto inglese, di 26 lettere, e, per semplicita, lasciate invariati tutti i segni di punteggiatura, gli spazi e le cifre, e considerate testi senza lettere accentate.
Supponete che il testo sia terminato da un asterisco.
Ad esempio, se il programma legge the times they are a-changin’*,
e la chiave è 5, dovrà stampare ymj ynrjx ymjd fwj f-hmfsln’

Come fareste a decifrare un messaggio cifrato in questo modo, supponendo di conoscere la chiave? E supponendo di non conoscere la chiave? */

#include <stdio.h>
#include <stdlib.h>
#define cifratura 5

int main(int argc, char *argv[]) {
  
exit(EXIT_SUCCESS);
}
